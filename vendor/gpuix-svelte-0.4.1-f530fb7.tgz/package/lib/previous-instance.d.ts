/**
 * The relaunch handshake, Electron's relauncher in portable form. The process that installed an
 * update starts the new executable with its own pid in `GPUIX_RELAUNCH_AFTER` and a sentinel path
 * in `GPUIX_RELAUNCH_READY`, then waits for the sentinel before it exits (and rolls the update
 * back if it never comes). The new instance, here, writes the sentinel as soon as it runs this
 * code, then waits for the old pid to be gone before it opens a window, so the two never overlap
 * and a single-instance app never sees its predecessor. No imports: render.ts calls it and has to
 * stay bundleable for the browser, where there is no process at all.
 */
export type PreviousInstance = 'exited' | 'timed-out' | false;
/**
 * Reports to the instance that installed this one and blocks until it has exited: `'exited'`,
 * or `'timed-out'` after `timeout_ms` (a warning is logged and the caller carries on), or false
 * when this process was not started by an update.
 */
export declare function wait_for_previous_instance(timeout_ms?: number): PreviousInstance;
/** The version this process replaced through an update, or null; the same answer on every call in this process. */
export declare function updated_from(): string | null;
