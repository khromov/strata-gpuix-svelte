/**
 * The packaging around a compiled executable — the macOS `.app`'s plist, icns, signature and
 * notarization, the Windows `.ico` — and the app metadata both are filled from, as the entry's
 * source declares it. Nothing here needs Bun, so the tests run it on Node; `build.ts` is the Bun half.
 */
import type { AppOptions, AppUpdateOptions } from './types.js';
export interface AppInfo {
    name: string;
    /** `name` as a file name: lowercase ASCII words joined by `-`. */
    slug: string;
    identifier: string;
    version: string;
    /** Absolute path; `DEFAULT_ICON` when the entry gives none. */
    icon: string;
    copyright?: string;
    publisher?: string;
    description?: string;
    update?: AppUpdateOptions;
}
/** What the executable knows about itself at runtime: `AppInfo` without the build-only icon, as `GPUIX_APP_INFO`. */
export type EmbeddedAppInfo = Omit<AppInfo, 'icon'>;
/** One platform's build, as `build({ archive: true })` writes it beside the archive for `gpuix-svelte update manifest`. */
export interface UpdateFragment {
    platform: string;
    version: string;
    file: string;
    sha256: string;
    size: number;
}
/** The `app` options and window title written in the entry's `render()` call. */
export type EntryApp = AppOptions & {
    title?: string;
};
export declare const MIN_MACOS = "13.0";
export declare const DEFAULT_ICON: string;
/** `title` and `app` from the entry's one top-level `render()` call; `source` is JavaScript, its types already stripped. */
export declare function read_app_options(source: string): EntryApp;
export declare function app_slug(name: string): string;
export declare function resolve_app_info(declared: EntryApp, entry: string): AppInfo;
/** `update-<platform>.json`'s platform key, the same string `gpuix-svelte/update` looks its asset up by. */
export declare function update_platform(platform?: NodeJS.Platform, arch?: NodeJS.Architecture): string;
/** `<slug>-<version>-<platform>.zip`. */
export declare function archive_name(info: Pick<AppInfo, 'slug' | 'version'>, platform?: string): string;
/**
 * The archive that ships and that `gpuix-svelte/update` installs: the `.app`, `.exe` or
 * executable at the zip's top level, written by src/zip.ts on every platform (modes kept, so
 * the executable bit and a signature's layout survive).
 */
export declare function write_archive(output: string, out: string): void;
export declare function sha256_file(path: string): string;
export declare function update_fragment(info: Pick<AppInfo, 'version'>, archive: string, platform?: string): UpdateFragment;
export declare function info_plist(info: AppInfo): string;
export declare const ENTITLEMENTS = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n<plist version=\"1.0\">\n<dict>\n\t<key>com.apple.security.cs.allow-jit</key>\n\t<true/>\n\t<key>com.apple.security.cs.allow-unsigned-executable-memory</key>\n\t<true/>\n\t<key>com.apple.security.cs.disable-executable-page-protection</key>\n\t<true/>\n\t<key>com.apple.security.cs.allow-dyld-environment-variables</key>\n\t<true/>\n\t<key>com.apple.security.cs.disable-library-validation</key>\n\t<true/>\n</dict>\n</plist>\n";
/** Scales a PNG with what the platform ships: sips on macOS, .NET's System.Drawing through PowerShell on Windows. */
export declare function resize_png(png: string, size: number, out: string): void;
/** iconutil reads only an .iconset directory holding the ten standard sizes; both tools ship with macOS. */
export declare function write_icns(png: string, out: string, scratch: string): void;
export declare const ICO_SIZES: number[];
export declare function write_ico(png: string, out: string, scratch: string): void;
/** An .ico is a directory over image blobs; Windows has read PNG-compressed entries since Vista, 256 px included. */
export declare function ico(images: Array<{
    size: number;
    bytes: Uint8Array;
}>): Buffer;
export declare function sign(target: string, identity: string, scratch: string): void;
/** A keychain profile on a developer's machine; an Apple ID with an app-specific password on CI, where no keychain profile exists. */
export type NotaryAuth = {
    profile: string;
} | {
    apple_id: string;
    password: string;
    team_id: string;
};
/** `NOTARY_PROFILE`, else `APPLE_ID` + `APPLE_PASSWORD` + `APPLE_TEAM_ID`; null when neither is complete. */
export declare function notary_auth(env?: Record<string, string | undefined>): NotaryAuth | null;
/**
 * Stapling only works on a bundle, and the ticket has to be stapled before the zip that ships is
 * made, so the submission zip is rebuilt afterwards; `zip` is the one to ship.
 */
export declare function notarize(bundle: string, auth: NotaryAuth, zip: string, log: (line: string) => void): void;
export declare function run(command: string, args: string[], env?: Record<string, string>, cwd?: string): string;
