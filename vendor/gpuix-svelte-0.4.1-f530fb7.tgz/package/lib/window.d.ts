/**
 * Window-level calls app code makes that the headless renderer cannot answer —
 * `TestGpuixRenderer` has no window to title, activate or blur — so each one is a
 * no-op there, which spares every component a guard.
 */
import type { PathPromptOptions } from '@gpuix/native';
import type { Native, PixelFormat, ShadowNode } from './types.js';
import { type DebugFrameOverlayMode, type DebugFrameOverlayStats, type WindowInsets, type WindowSize } from '@gpuix/native/host';
/** A shadow node, from `{@attach}` or `use:`. */
type NodeRef = {
    nativeId?: number | null;
} | null | undefined;
/**
 * Runs a read that waits on GPUI's UI thread, for a timer or an effect that must not stall or throw:
 * null when there is no native, a dialog is open or the thread can't answer.
 */
export declare function read_native<T>(read: (native: Native) => T): T | null;
export declare function set_window_title(title: string): void;
/** Brings a window opened with `show: false` or `focus: false` forward. */
export declare const activate_window: () => void | undefined;
export declare const minimize_window: () => void | undefined;
/** macOS's zoom, maximize elsewhere. */
export declare const zoom_window: () => void | undefined;
export declare const toggle_fullscreen: () => void | undefined;
/** The platform file picker: absolute paths, or null when the user cancels. Rejects in a browser. */
export declare function prompt_for_paths(options?: PathPromptOptions): Promise<string[] | null>;
/** Gives focus back from an `<input>` / `<textarea>` to the window. */
export declare const blur: () => void | undefined;
export declare function focus_element(node: NodeRef): void;
export declare const focused_element: () => ShadowNode | null;
/** Moves focus to the next tab stop in the window, wrapping at the end; Tab itself moves nothing since native 0.7. */
export declare const focus_next: () => void | undefined;
export declare const focus_previous: () => void | undefined;
/** Moves focus to the next tab stop inside `node`, wrapping within it. */
export declare function focus_next_within(node: NodeRef): void;
export declare function focus_previous_within(node: NodeRef): void;
/** Scrolls the nearest scroll container or `<virtual-list>` until `node` is visible. */
export declare function scroll_into_view(node: NodeRef): void;
/**
 * Encoded image bytes (PNG, JPEG, WebP, GIF, SVG, …) onto an `<img>`, no data URL in between.
 * Native forgets them when the element is destroyed or its `src` changes, so call it again then.
 */
export declare function set_image(node: NodeRef, bytes: Uint8Array): void;
/** Packed straight-alpha pixels, scaled into the element's box like any image, so a 2× bitmap stays sharp on retina. */
export declare function set_image_pixels(node: NodeRef, width: number, height: number, pixels: Uint8Array, format?: PixelFormat): void;
/**
 * A TrueType or OpenType file (or collection), usable by `font-family` under the names it declares.
 * Throws on a font GPUI can't use; the wasm build has no fonts to add to, so it does nothing there.
 */
export declare const register_font: (bytes: Uint8Array) => void | undefined;
/** The elements painted under a window point, topmost first, like the DOM's `elementsFromPoint`. */
export declare const elements_at: (x: number, y: number) => ShadowNode[];
export declare function set_debug_overlay(mode: DebugFrameOverlayMode): DebugFrameOverlayMode | undefined;
/** Hidden → minimal → full → hidden. */
export declare const cycle_debug_overlay: () => DebugFrameOverlayMode | undefined;
export declare const debug_overlay: () => DebugFrameOverlayMode | undefined;
/** Recorded whether or not the overlay is showing; the wasm build has none. */
export declare const debug_overlay_stats: () => DebugFrameOverlayStats | undefined;
/** Clears the draw samples behind the percentiles; the frame count keeps going. */
export declare const reset_debug_overlay_stats: () => void | undefined;
/** The window's logical size, reactive in a template or effect; 800×600 until a native exists. */
export declare const window_size: Readonly<WindowSize>;
/** Safe-area, IME and combined insets and what follows from them, polled like `window_size`; zero headlessly. */
export declare const window_insets: Readonly<WindowInsets>;
export {};
