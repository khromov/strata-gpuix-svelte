/**
 * The `browser` condition's entry: everything `index.ts` has except `render_hot`,
 * whose `node:fs` watch cannot resolve in a browser bundle.
 */
export { render } from './render.js';
export { default as renderer, set_native, get_native, create_root, commit, is_dirty, set_auto_commit, dispatch, set_css_vars, set_keyboard_focus_dim, on_window_key, on_selection_change } from './renderer.js';
export { parse_css_text, build_style } from './style.js';
export { to_gpui_event, GPUI_EVENTS } from './events.js';
export { set_window_title, activate_window, minimize_window, zoom_window, toggle_fullscreen, prompt_for_paths, read_native, blur, focus_element, focused_element, focus_next, focus_previous, focus_next_within, focus_previous_within, scroll_into_view, set_image, set_image_pixels, register_font, elements_at } from './window.js';
export { TextSearch, find_ranges, type TextSearchOptions } from './search.js';
export type { ShadowNode, ShadowAttrs, NodeKind, EventHandler, GpuixEvent, GpuiStyle, StyleValue, StyleRule, ClassRule, Mutation, NativeSink, Native, RenderOptions, AppOptions, WindowKeyType, PixelFormat, AnyComponent } from './types.js';
export type { GpuixTheme, HighlightSpec, MotionProps } from '@gpuix/native/host';
export { set_debug_overlay, cycle_debug_overlay, debug_overlay, debug_overlay_stats, reset_debug_overlay_stats } from './window.js';
export type { DebugFrameOverlayMode, DebugFrameOverlayStats } from '@gpuix/native/host';
export { window_size, window_insets } from './window.js';
export type { WindowSize, WindowInsets, EdgeInsets } from '@gpuix/native/host';
