/**
 * The update archive is a zip, made and opened by adm-zip (no dependencies, node:zlib underneath)
 * on every platform, so neither the build nor the updater needs ditto, tar or unzip. This is the
 * thin layer around it: every entry's path is checked before it is written, Apple's `._` and
 * `__MACOSX` sidecars are skipped (left in, they would break a signed bundle's seal), modes are
 * kept but never group- or world-writable, and symlinks are refused at both ends (adm-zip would
 * write one as a file holding its target, which silently breaks what depends on it; a bundle
 * gpuix-svelte builds has none).
 */
export declare class ZipError extends Error {
    constructor(message: string, options?: ErrorOptions);
}
/** Writes the archive's entries under `into` and returns how many; refuses any that would land outside it, and symlinks. */
export declare function extract_zip(zip_path: string, into: string): number;
/** `source` (a file, or a directory with everything under it, like `ditto --keepParent`) as a zip at `out`, modes kept. */
export declare function write_zip(source: string, out: string): void;
