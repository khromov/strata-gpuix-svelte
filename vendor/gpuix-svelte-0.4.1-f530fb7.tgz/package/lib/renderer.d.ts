/**
 * A JS shadow tree projected onto GPUI: it holds the fragments and comments GPUI has
 * no representation for, and allocates native ids lazily, because Svelte renders
 * offscreen constantly and eager creation would leak a Rust node per abandoned render.
 */
import type { EventPayload } from '@gpuix/native';
import { createRenderer } from 'svelte/renderer';
import type { ClassRule, GpuiStyle, GpuixEvent, Native, NativeSink, ShadowNode, WindowKeyType } from './types.js';
type Nodes = {
    fragment: ShadowNode;
    element: ShadowNode;
    text: ShadowNode;
    comment: ShadowNode;
};
type GpuixSvelteRenderer = ReturnType<typeof createRenderer<Nodes>>;
declare const renderer: GpuixSvelteRenderer;
export default renderer;
/** Runs at import time, from the call compile.ts appends to every component with a `<style>`. */
export declare function define_styles(scope: string, rules: ClassRule[]): void;
/**
 * A theme is one call: every live element whose style read a `var()` is restyled,
 * and the whole sweep ships in the next batch like any other frame. A palette identical
 * to the one in force — a theme effect re-running — is a no-op.
 *
 * `vars` is `{ surface: '#fff' }` for `var(--surface)`.
 */
export declare function set_css_vars(vars: Record<string, string | number | null>): void;
export declare function set_native(instance: NativeSink): void;
/** `render`'s `tabNavigation`: false leaves Tab to the app, as before native 0.11. */
export declare function set_tab_navigation(enabled: boolean): void;
/** Native 0.11's 40% dim of every other focusable while one has keyboard focus. */
export declare function set_keyboard_focus_dim(enabled: boolean): void;
/**
 * A key handler that fires whatever has focus — the ⌘K kind — without a focused
 * root `div` to hold on to; `event.editing` says a text field is getting the same key.
 * Returns the unsubscribe.
 */
export declare function on_window_key(type: WindowKeyType, handler: (event: GpuixEvent) => void): () => void;
/** Fires once per change of the window's text selection, a clear included; `event.value` is the selected text. */
export declare const on_selection_change: (handler: (event: GpuixEvent) => void) => () => void;
/** For components that need GPUI's answers back, e.g. scroll offsets and painted bounds. */
export declare const get_native: () => Native | null;
export declare const node_of: (id: number | null | undefined) => ShadowNode | null;
/** `position: relative`, so a portal's `inset: 0` means the window; a `null` dim leaves native's flag as it is. */
export declare function create_root(style?: GpuiStyle, keyboard_focus_dim?: boolean | null): ShadowNode;
export declare const is_dirty: () => boolean;
/** Lets a remount retire the previous root inside the new tree's batch. */
export declare function queue_destroy(nativeId: number): void;
/** Where no frame loop polls `is_dirty()`, mutations have to drain themselves. */
export declare function set_auto_commit(enabled: boolean): void;
/** Ships the whole frame's mutations as one call across the FFI boundary. */
export declare function commit(): void;
/** Runs `call` with the node's id once native has the element, which is now unless mutations are queued. */
export declare function with_native_id(node: {
    nativeId?: number | null;
} | null | undefined, call: (id: number) => void): void;
export declare function dispatch(payload: EventPayload): void;
