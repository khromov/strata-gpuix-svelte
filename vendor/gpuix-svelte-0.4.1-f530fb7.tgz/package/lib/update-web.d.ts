/**
 * `gpuix-svelte/update` under the `browser` condition: a page has no executable to replace, and
 * node:crypto's browser shim lacks the key functions, so a web bundle gets a check that says
 * "nothing to update" and keeps the same types.
 */
import type { CheckOptions, Update } from './update.js';
export type { CheckOptions, DownloadOptions, EmbeddedAppInfo, InstallOptions, NotInstallable, Update, UpdateAsset, UpdateErrorCode, UpdateFragment, UpdateManifest } from './update.js';
export type { PreviousInstance } from './previous-instance.js';
export declare class UpdateError extends Error {
    code: string;
    constructor(code: string, message: string);
}
export declare function app_info(): null;
export declare function check_for_update(_options?: CheckOptions): Promise<Update | null>;
export declare function finish_update(): void;
export declare function wait_for_previous_instance(): false;
export declare function updated_from(): null;
