/**
 * Installed via `node --import gpuix-svelte/register` so the hook is
 * in place before the entry module resolves.
 */
export { RENDERER_MODULE } from './compile.js';
