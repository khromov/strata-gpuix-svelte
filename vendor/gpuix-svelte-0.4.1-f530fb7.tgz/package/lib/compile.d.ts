/**
 * `experimental.customRenderer` is what makes the compiler emit
 * `import $renderer from 'gpuix-svelte/renderer'` and wrap the component in
 * `$.push_renderer($renderer)`.
 */
/**
 * The compiler bakes this into every component's `import $renderer from '...'`,
 * which must resolve from the `.svelte` file's own location — so components
 * outside this workspace need the override to supply an absolute path.
 */
export declare const RENDERER_MODULE: string;
/**
 * The registry's svelte carries the same version number as the custom-renderer build this
 * package bundles, so the loaders check for the API itself.
 */
export declare const WRONG_SVELTE = "[gpuix-svelte] svelte resolved to a build without the custom-renderer API. gpuix-svelte bundles the build it needs \u2014 remove svelte from your own dependencies and reinstall.";
/** Compiles the `.svelte` file at `path` to client JS; `query` is the `?v=N` cache-buster `render_hot` appends, if any. */
export declare function compile_svelte(path: string, query?: string): string;
/**
 * A `.svelte.ts` module has runes but no template, so it needs neither the renderer
 * import nor a cache-buster: it is loaded once and shared, which is what lets its
 * state outlive a hot remount. `source` is passed in when a loader has already
 * stripped the types, since `compileModule` does not.
 */
export declare function compile_module(path: string, source?: string): string;
