/**
 * Playwright-style driving through `@gpuix/native/automation`'s `App` and `Locator`:
 * `launch()` runs an entry under `GPUIX_AUTOMATION=1` and speaks upstream's SSE
 * protocol over its stdio, `test_app()` drives whatever `mount_headless` mounted.
 */
import { type ChildProcess } from 'node:child_process';
import { App, type TestAutomationRenderer } from '@gpuix/native/automation';
export { App, Locator, AutomationError, connectStdio, connectTest, PROTOCOL_VERSION } from '@gpuix/native/automation';
export type { AutomationBackend, AutomationErrorCode, DragOptions, ElementBounds, MouseOptions, PointTarget, TestAutomationRenderer, TreeNode } from '@gpuix/native/automation';
export interface LaunchOptions {
    /** The app's entry module, resolved against `cwd`. */
    entry: string;
    /** Run the app on Bun even when this script runs on Node; under Bun it already does. */
    bun?: boolean;
    /** Arguments after the entry. */
    args?: string[];
    cwd?: string;
    env?: Record<string, string | undefined>;
}
/**
 * Runs `entry` through the `gpuix-svelte` bin with `GPUIX_AUTOMATION=1` and connects to it once it
 * answers `initialize`. `close()` ends the app's stdin, which exits it, and kills it if it is still
 * there two seconds later.
 */
export declare function launch({ entry, bun, args, cwd, env }: LaunchOptions): Promise<App & {
    process: ChildProcess;
}>;
/** An `App` over what `mount_headless` mounted: the locator script `launch()` runs, without a window. */
export declare const test_app: () => Promise<App>;
/**
 * Upstream's `TestAutomationRenderer` over the headless renderer, with test.ts's discipline:
 * every input is simulate → drainEvents → dispatch → settle, and reads pump first, so a timer's
 * update or a queued `layout` event reaches `waitFor` the way the window would deliver it.
 */
export declare function headless_renderer(): TestAutomationRenderer;
