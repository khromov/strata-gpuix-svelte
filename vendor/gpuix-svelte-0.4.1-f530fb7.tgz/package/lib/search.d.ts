import { type HighlightSpec } from '@gpuix/native/host';
import type { GpuixEvent } from './types.js';
export interface TextSearchOptions {
    case_sensitive?: boolean;
    whole_word?: boolean;
    color?: string;
    active_color?: string;
    radius?: number;
}
/** Find-in-text over native `highlight`: `highlight={search.spec} onhighlight={search.on_highlight}` on the element to search. */
export declare class TextSearch {
    #private;
    constructor({ case_sensitive, whole_word, color, active_color, radius }?: TextSearchOptions);
    get query(): string;
    set query(value: string);
    get case_sensitive(): boolean;
    set case_sensitive(value: boolean);
    get whole_word(): boolean;
    set whole_word(value: boolean);
    get spec(): HighlightSpec | null;
    get total(): number;
    get active(): number;
    readonly on_highlight: (e: GpuixEvent) => void;
    readonly next: () => void;
    readonly prev: () => void;
    readonly go_to: (index: number) => void;
}
/** Native's matcher in JS, for `ranges` and `matchIndexOffset` over text native has not mounted (a virtual list's offscreen rows). */
export declare function find_ranges(text: string, query: string, { case_sensitive, whole_word }?: Pick<TextSearchOptions, 'case_sensitive' | 'whole_word'>): [number, number][];
