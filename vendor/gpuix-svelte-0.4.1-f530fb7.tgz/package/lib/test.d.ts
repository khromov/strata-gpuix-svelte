/**
 * Headless testing on the real GPUI pipeline. `TestGpuixRenderer` runs Metal or
 * DirectX without a window; this is the mount / settle / hit-test loop around it
 * that every test used to spell out, bound to whatever native the renderer holds.
 */
import { TestGpuixRenderer, type ElementBounds, type HighlightMatch } from '@gpuix/native';
import { type Component } from 'svelte';
import type { GpuiStyle, ShadowNode } from './types.js';
/** On macOS the headless viewport can be any width but never taller than this; Windows ignores the requested size. */
export declare const MAX_HEADLESS_HEIGHT = 538;
/** One node of `getTreeJson()`: what GPUI holds, with the ids the shadow tree assigned. */
export interface TreeNode {
    id: number;
    type: string;
    text?: string;
    testId?: string;
    events?: string[];
    style?: GpuiStyle;
    children?: TreeNode[];
}
/**
 * One node of `getAutomationTree()`, which carries last-paint bounds but no style or events;
 * `getTreeJson()` is the reverse, which is why `tree()` stays on it.
 */
export interface AutomationNode {
    id: number;
    type: string;
    text?: string;
    testId?: string;
    bounds?: ElementBounds;
    children?: AutomationNode[];
}
/** A tree node, a shadow node, an automation node or a bare native id. */
export type Target = number | {
    id?: number;
    nativeId?: number | null;
};
export interface Point {
    x: number;
    y: number;
}
/** A target (its centre) or window coordinates. */
export type PointTarget = Target | Point;
export interface FindOptions {
    last?: boolean;
}
export interface MouseOptions {
    /** 0 = left (default), 1 = middle, 2 = right. */
    button?: number;
    /** In `press()` syntax: `'cmd'`, `'cmd-shift'`, `'alt'`. */
    modifiers?: string;
}
export interface MoveOptions {
    /** The button held during the move, which makes it a drag. */
    pressed_button?: number;
    modifiers?: string;
}
export interface DragOptions extends MouseOptions {
    /** Moves between the press and the release; default 8. */
    steps?: number;
}
export interface WaitForOptions {
    /** Default 2000 ms. */
    timeout?: number;
    /** Default 16 ms. */
    interval?: number;
    /** Names the condition in the timeout error; defaults to the predicate's source. */
    label?: string;
}
export type ClickOptions = FindOptions & MouseOptions;
export interface MountHeadlessOptions {
    props?: Record<string, unknown>;
    width?: number;
    height?: number;
    rootStyle?: GpuiStyle;
    keyboardFocusDim?: boolean;
    tabNavigation?: boolean;
    /** `render`'s title bar, with this title; its close button unmounts the component instead of exiting. */
    titlebar?: string;
}
export declare function mount_headless<Exports extends Record<string, unknown> = Record<string, unknown>>(Component: Component<any, Exports, any>, { props, width, height, rootStyle, keyboardFocusDim, tabNavigation, titlebar }?: MountHeadlessOptions): {
    native: TestGpuixRenderer;
    root: ShadowNode;
    anchor: ShadowNode;
    component: Exports;
    unmount: () => Promise<void>;
};
/** Focuses an element through native, whose `focus`/`blur` events reach the tree as a window's would. */
export declare function focus(target: Target): void;
/** The counterpart of `blur()`, which the test renderer lacks: reports the blur to the tree. */
export declare function unfocus(): void;
/** Runs Svelte's effects, ships the batch, and lets GPUI lay out and paint. */
export declare function settle(): void;
/**
 * For updates that arrive on a timer, a promise or an event native queued while painting. A window hands
 * those events over right after the paint, so they land before the wait starts, not when it ends.
 */
export declare function wait(ms?: number): Promise<void>;
export declare const tree: () => TreeNode;
export declare function find_all(pred: (node: TreeNode, parent: TreeNode | null) => boolean): TreeNode[];
export declare function find(pred: (node: TreeNode, parent: TreeNode | null) => boolean, { last }?: FindOptions): TreeNode | null;
export declare const find_text: (text: string, opts?: FindOptions) => TreeNode | null;
export declare const find_test_id: (id: string, opts?: FindOptions) => TreeNode | null;
/** The element around the text node with this content, as GPUI holds it. */
export declare function element_of(text: string, { last }?: FindOptions): TreeNode | null;
/** `{ x, y, width, height }` in logical px, from a tree node, a shadow node or an id. */
export declare const bounds: (target: Target) => ElementBounds | null;
/** Hands every event native queued to the renderer, as the window's callback would. */
export declare function drain(): void;
/**
 * Drains and settles until native has nothing left to report, because the paint a settle
 * triggers can queue events of its own (a hover change, a selection, a finished motion).
 */
export declare function pump(): void;
/** The element's painted centre, or a throw naming why a pointer could not land there. */
export declare function center(target: Target): Point;
/** A point passes through unchecked, so a gesture can end outside every element; anything else is its centre. */
export declare const point_of: (target: PointTarget) => Point;
/**
 * A click at the element's centre through GPUI's own hit testing, occlusion included.
 * `dispatch()` straight at an element skips that, and can pass while the window fails.
 */
export declare function click(target: Target, { button, modifiers }?: ClickOptions): void;
/** A Finder-style drop of `paths` on the element's centre, hit-tested like a click. */
export declare function drop_files(target: Target, paths: string[]): void;
/** A click at window coordinates, through the same hit testing. */
export declare function click_at(x: number, y: number, { button, modifiers }?: ClickOptions): void;
export declare function click_text(text: string, opts?: ClickOptions): void;
export declare function click_test_id(id: string, opts?: ClickOptions): void;
/** Moves the pointer there, for `onmouseenter`/`onmouseleave` and `hover=` styles. */
export declare function hover(target: PointTarget, opts?: MoveOptions): void;
export declare function mouse_move(target: PointTarget, { pressed_button, modifiers }?: MoveOptions): void;
export declare function mouse_down(target: PointTarget, { button, modifiers }?: MouseOptions): void;
export declare function mouse_up(target: PointTarget, { button, modifiers }?: MouseOptions): void;
/** One wheel event in px; a negative `delta_y` scrolls down, which is the direction GPUI's offsets go. */
export declare function wheel(target: PointTarget, delta_x: number, delta_y: number, { modifiers }?: {
    modifiers?: string;
}): void;
/**
 * Press at `from`, travel to `to` in `steps` moves with the button held, release there.
 * Both ends resolve before the press, since a live preview can move the target under it.
 */
export declare function drag(from: PointTarget, to: PointTarget, { button, modifiers, steps }?: DragOptions): void;
/**
 * Drag-selects text and returns what got selected. Native does the down/move/up itself,
 * because the selection listeners register during paint and need a flush between each.
 */
export declare function drag_select(from: PointTarget, to: PointTarget): string | null;
/** The current text selection joined in document order, or null. */
export declare const selected_text: () => string | null;
export declare function clear_selection(): void;
/** Every `highlight` wash painted in the last frame, with its rects; the quads never reach `painted()`. */
export declare const painted_highlights: () => HighlightMatch[];
export declare function clock_pause(): number;
export declare function clock_set(now_ms: number): number;
export declare function clock_fast_forward(delta_ms: number): number;
export declare function clock_resume(): number;
/** Runs GPUI's own due timers (caret blink, drag autoscroll); the motion clock and `setTimeout` keep their own time. */
export declare function advance_time(ms: number): void;
/**
 * Polls until `pred()` is truthy and resolves with its value, pumping between tries so
 * timers, promises and native events all get to land.
 */
export declare function wait_for<T>(pred: () => T, { timeout, interval, label }?: WaitForOptions): Promise<NonNullable<T>>;
export declare function automation_tree(): AutomationNode | null;
/** One key in GPUI's keystroke syntax — `'escape'`, `'cmd-k'`, `'shift-tab'`. */
export declare function press(keystroke: string, { held }?: {
    held?: boolean;
}): void;
/** The key-up half `press()` leaves out, for `onkeyup` and `on_window_key('keyup')`. */
export declare function key_up(keystroke: string): void;
/** Space-separated keystrokes through the focused element's input pipeline. */
export declare function type(keystrokes: string): void;
export declare const painted: () => string;
export declare const all_text: () => string[];
export declare function screenshot(path: string): string;
export declare function check(label: string, actual: unknown, expected?: unknown): boolean;
export declare const failed: () => number;
/**
 * Prints the verdict and exits, so nothing left on a timer keeps the process alive.
 * `expected` is how many `check` calls should have run: nothing else counts them, so
 * assertions that stop executing would otherwise take the file green with them.
 */
export declare function finish(name: string, expected?: number): never;
export type { ShadowNode, HighlightMatch };
