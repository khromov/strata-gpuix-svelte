/**
 * Deriving the map by lowercasing GPUI's own list keeps it in sync with the names
 * Svelte emits, which the compiler has already lowercased.
 */
export declare const GPUI_EVENTS: readonly string[];
/** Not element events: they arrive on the id handed to `setWindowKeyEvents` (see `on_window_key`). */
export declare const WINDOW_KEY_EVENTS: Partial<Record<string, 'windowKeyDown' | 'windowKeyUp'>>;
/** The GPUI spelling of an event name as Svelte spells it (`mouseenter`), or null if GPUI has no such event. */
export declare function to_gpui_event(type: string): string | null;
