/**
 * GNOME's Wayland compositor draws no title bar for a window that asks it to, and native has
 * no window move or resize to build a full one with, so `render`'s `titlebar` option draws
 * this static bar instead: the title, minimise, maximise and close.
 */
import type { GpuiStyle, ShadowNode } from './types.js';
export interface TitlebarSpec {
    title: string;
    on_close(): void;
}
/** Keeps the bar in step with `set_window_title`. */
export declare function set_titlebar_title(title: string): void;
/** The window's root, and the node the app mounts into: the root itself, or the box under the bar. */
export declare function create_window_root(root_style: GpuiStyle | undefined, keyboard_focus_dim: boolean | null | undefined, titlebar: TitlebarSpec | null): {
    root: ShadowNode;
    target: ShadowNode;
};
/** `'auto'`, the default, draws the bar only where nothing else would: GNOME, which GPUI reaches over Wayland. */
export declare function wants_titlebar(option: boolean | 'auto' | undefined, env: (name: string) => string | undefined, platform?: NodeJS.Platform): boolean;
