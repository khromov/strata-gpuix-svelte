/**
 * Unknown keys need no allowlist — serde drops them when deserializing
 * `StyleDesc` on the Rust side. Values are the opposite: a key GPUI *does*
 * know, handed a string it can't parse, throws out of `applyBatch`.
 */
import type { GpuiStyle, ShadowAttrs, StyleRule } from './types.js';
/** Keys with or without the `--`; false when nothing moved, so an identical palette costs no restyle. */
export declare function define_css_vars(vars: Record<string, string | number | null>): boolean;
/** Deferred to the commit, since Svelte styles the tree before the root's `$effect` can set the palette. */
export declare function flush_var_warnings(): void;
/** Whether the last `build_style` read a variable, so the renderer knows what to restyle. */
export declare const used_css_vars: () => boolean;
export declare function parse_css_text(css: string | null | undefined): GpuiStyle;
/**
 * `hover`, `active` and `focusVisible` are GPUI's natively-handled pseudo styles —
 * nested objects, which CSS text can't express, so they arrive as their own
 * attributes (or as `:hover`/`:active`/`:focus-visible` rules) and get folded back in here.
 *
 * `attrs` are the raw attribute strings off the shadow node; `rules` the element's
 * matching `<style>` rules, weakest first.
 */
export declare function build_style(attrs: ShadowAttrs, rules?: readonly StyleRule[]): GpuiStyle;
