/**
 * The structure mirrors `@gpuix/react`'s `render()` — a `globalThis` slot so
 * `hot.ts` remounts onto the same window, and a paced `setTimeout` loop
 * driving `tick()`. It imports no `node:*` module, so it bundles for the browser as-is.
 */
import { GpuixRenderer, type EventPayload, type WindowOptions } from '@gpuix/native';
import type { DebugFrameOverlayMode } from '@gpuix/native/host';
import type { AnyComponent, AppOptions, RenderOptions } from './types.js';
/**
 * A throwing handler must not escape into the native callback, and must not
 * cost the host its own `onEvent`.
 */
export declare function handle_event(event: EventPayload, onEvent?: (event: EventPayload) => void): void;
/** Resolves after the frame loop's next `tick()`, or a frame's worth of time where there is no loop. */
export declare function next_frame(): Promise<void>;
export declare function start_frame_loop(native: Pick<GpuixRenderer, 'requiresTick' | 'tick'>): {
    stop(): void;
};
/**
 * `GPUIX_FPS` (`1` is `full`) applies once per window and outranks the option, which applies again
 * only when it changed: `render_hot` remounts with the same options, and a cycled mode must survive.
 */
export declare function overlay_on_render(fps: string | undefined, option: DebugFrameOverlayMode | undefined, applied: DebugFrameOverlayMode | undefined, created: boolean): string | undefined;
/** The keyboard-focus dim to ship, or `null` to keep a runtime `set_keyboard_focus_dim` across a `render_hot` remount. */
export declare function focus_dim_on_render(option: boolean | undefined, applied: boolean | undefined, created: boolean): boolean | null;
/** The identifier becomes the app id because that is what a Linux desktop matches a window's `.desktop` file by. */
export declare function window_options_for(options: WindowOptions, app: AppOptions | undefined): WindowOptions;
/** Mounts a compiled `.svelte` component into the window, creating it on the first call. */
export declare function render(Component: AnyComponent, options?: RenderOptions): Record<string, unknown>;
