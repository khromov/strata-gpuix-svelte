/**
 * The live end of `gpuix-svelte/automation`: upstream's SSE protocol on stdin/stdout,
 * answered by the window's own `GpuixRenderer`. `render()` loads it only under
 * `GPUIX_AUTOMATION=1`, so neither the app path nor the web bundle carries it.
 */
import type { GpuixRenderer } from '@gpuix/native';
import { type AutomationBackend } from '@gpuix/native/automation';
export declare function serve_automation(native: GpuixRenderer, next_frame: () => Promise<void>): void;
/**
 * One request at a time, and an input replies only once its effect is laid out, so
 * a `getTree` sent after a `click`, pipelined or not, reads the clicked state.
 */
export declare function frame_synced(inner: AutomationBackend, native: Pick<GpuixRenderer, 'getWindowSize'>, next_frame: () => Promise<void>): AutomationBackend;
