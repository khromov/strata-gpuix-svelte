/**
 * Preloaded (`--preload gpuix-svelte/plugin` from the bin, or `bunfig.toml`'s `preload`) so
 * it is in place before the entry module resolves. `Bun.build` ignores runtime registrations,
 * so the hooks are also exported for a build script to wire up itself.
 */
import { type OnLoadArgs, type OnLoadResult, type OnResolveArgs } from 'bun';
export { RENDERER_MODULE } from './compile.js';
export declare function load_svelte(args: OnLoadArgs): OnLoadResult;
export declare function load_module(args: OnLoadArgs): OnLoadResult;
export declare const resolve_native_cjs: () => {
    path: string;
};
/**
 * `Bun.build` resolves `svelte` from the importer, and in a consumer's project that can be the
 * registry build svelte-check hoists, so this pins it to the copy bundled here, under the build's
 * own conditions. Use as `build.onResolve({ filter: /^svelte(\/|$)/ }, resolve_svelte(conditions))`.
 */
export declare function resolve_svelte(conditions: string[]): (args: OnResolveArgs) => {
    path: string;
} | undefined;
