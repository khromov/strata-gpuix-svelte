/**
 * Split out of `render.ts` so a browser bundle of the package never resolves
 * `node:fs` — hot reload is the only thing here that needs it.
 */
import type { RenderOptions } from './types.js';
/** The newest `url` and the components under it; `.svelte.ts` modules keep their single instance. */
export declare function import_fresh(url: URL, version: number): Promise<Record<string, unknown>>;
/** What a change under the entry's directory calls for; `compile.ts` never busts a package's specifiers, so a remount there would load the same code. */
export declare function on_change(file: string): 'remount' | 'restart' | null;
/**
 * An in-process watch keeps one Svelte runtime for the life of the process, so the
 * old tree unmounts properly; `bun --hot` would re-evaluate that runtime.
 *
 * `entry` is the root `.svelte` component, as a path or a `file:` URL.
 */
export declare function render_hot(entry: string | URL, options?: RenderOptions): Promise<void>;
