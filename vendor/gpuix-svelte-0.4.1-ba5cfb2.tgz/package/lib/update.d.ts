/**
 * `gpuix-svelte/update` — in-app updates for a compiled app. A static manifest on any HTTPS host
 * names the newest version, its notes and a sha256-checked archive per platform;
 * `check_for_update()` reads it, and the `Update` it returns downloads, verifies and swaps the
 * running app for the new one. The build bakes the manifest URL, the public key and the version
 * into the executable as `GPUIX_APP_INFO`, which is also how a dev run can pretend to be one.
 * Everything here is node:* (the zip is src/zip.ts through adm-zip), so it runs on Node
 * and Bun alike and the tests cover the swap on a copy.
 */
import type { EmbeddedAppInfo, UpdateFragment } from './app-bundle.js';
export type { EmbeddedAppInfo, UpdateFragment } from './app-bundle.js';
export { updated_from, wait_for_previous_instance, type PreviousInstance } from './previous-instance.js';
export interface UpdateAsset {
    url: string;
    /** Hex sha256 of the file at `url`. */
    sha256: string;
    size?: number;
}
export interface UpdateManifest {
    version: string;
    /** Release notes, markdown. */
    notes?: string;
    /** ISO 8601. */
    published_at?: string;
    /** A page for people whose copy can't be updated in place (a read-only install, say). */
    url?: string;
    /** Keyed by `<process.platform>-<process.arch>`: `darwin-arm64`, `win32-x64`, `win32-arm64`, `linux-x64`. */
    platforms: Record<string, UpdateAsset>;
    /** Base64 ed25519 signature over `canonical_manifest()`, from `gpuix-svelte update manifest --key`. */
    signature?: string;
}
export type UpdateErrorCode = 'version' | 'manifest' | 'signature' | 'download' | 'hash' | 'extract' | 'install' | 'not-installable';
export declare class UpdateError extends Error {
    code: UpdateErrorCode;
    constructor(code: UpdateErrorCode, message: string, options?: ErrorOptions);
}
/**
 * Why `install()` would refuse: a dev run (`npm start`, a test, or an executable the build did
 * not make), nothing in the manifest for this platform, a macOS app Gatekeeper is running from a
 * read-only translocated copy (it was opened straight from the download instead of being moved
 * to Applications), an install directory this user can't write, or a platform without a swap.
 */
export type NotInstallable = 'development' | 'no-asset' | 'translocated' | 'read-only' | 'unsupported';
export interface CheckOptions {
    /** Overrides the app's `update.manifest`. In a dev run `GPUIX_UPDATE_MANIFEST` in the environment outranks both; a built app ignores the variable. */
    manifest?: string;
    /** Overrides the app's `update.publicKey`. */
    publicKey?: string;
    /** The running version; the built app's by default. */
    version?: string;
    /** `<process.platform>-<process.arch>` by default. */
    platform?: string;
    /** What to replace — the `.app`, `.exe` or executable. For tests: by default it is the running app, and only when the running executable is a built app. */
    target?: string;
    fetch?: typeof fetch;
}
export interface DownloadOptions {
    /** `total` is the manifest's `size`, else the response's `content-length`, else null. */
    onProgress?: (received: number, total: number | null) => void;
    /** Aborting it fails the download with code `download` and removes what was written. */
    signal?: AbortSignal;
}
export interface InstallOptions extends DownloadOptions {
    /** Start the new version and exit this process once the swap is done; `false` keeps running on the old code until the next launch. Default true. */
    relaunch?: boolean;
    /** The arguments the new version starts with; this process's own (`process.argv.slice(2)`) by default. */
    args?: string[];
}
export interface Update {
    readonly version: string;
    readonly current: string;
    readonly notes: string;
    readonly published_at?: string;
    readonly url?: string;
    readonly platform: string;
    /** Null when the manifest has nothing for this platform. */
    readonly asset: UpdateAsset | null;
    readonly installable: boolean;
    readonly reason?: NotInstallable;
    /** True once `install()` has swapped the app and the swap stood; a second `install()` then throws. */
    readonly installed: boolean;
    /**
     * Fetches the archive into a temp directory and checks its size and sha256; resolves to its path, and `install()` calls it when it has not run.
     * A download in flight is shared: a later caller's `onProgress` joins it and its `signal` ends only its own wait, while the first caller's stops it for everyone.
     */
    download(options?: DownloadOptions): Promise<string>;
    /** Extracts, checks that what came out is this app (its kind of executable; on macOS the bundle's identifier and version) and swaps it in for the running app. */
    install(options?: InstallOptions): Promise<void>;
}
/** What the build wrote into the executable; null under `npm start`, or on Node, unless `GPUIX_APP_INFO` is set by hand. */
export declare function app_info(): EmbeddedAppInfo | null;
export declare function check_for_update(options?: CheckOptions): Promise<Update | null>;
/**
 * Deletes what earlier updates left: the archive or staging directory of an app that was closed
 * or killed midway, and on Windows the old `.exe`, which can't be deleted while it runs, only
 * renamed, so it waits as `<name>.exe.old` until the next launch.
 * `check_for_update()` does this; call it at startup in an app that checks later or never.
 */
export declare function finish_update(target?: string): void;
/**
 * The string values of an XML `Info.plist`'s top-level dictionary, which is all a bundle check
 * needs; null for a binary or unreadable plist. The build writes XML, and Apple's signing and
 * stapling leave it so. Comments, CDATA and processing instructions are dropped first and only
 * the first `<plist>` counts, so they can't carry a decoy; this is a guard against mistakes, not
 * a signature check.
 */
export declare function plist_strings(path: string): Map<string, string> | null;
/** `1.2.0-beta.1 < 1.2.0 < 1.10.0`, as semver orders them; a leading `v` is ignored. */
export declare function compare_versions(a: string, b: string): -1 | 0 | 1;
/** Whether `compare_versions` can read it: `major[.minor[.patch]][-prerelease][+build]`. */
export declare function is_version(version: string): boolean;
/** The bytes a signature covers: the manifest without `signature`, keys sorted, no whitespace. */
export declare function canonical_manifest(manifest: UpdateManifest): string;
/** Whether `key` is what `generate_keys()` prints: 32 raw ed25519 bytes, base64. */
export declare function is_public_key(key: string): boolean;
/** A fresh ed25519 pair: `publicKey` goes into `app.update.publicKey`, `privateKey` (PEM) stays a secret. */
export declare function generate_keys(): {
    publicKey: string;
    privateKey: string;
};
export declare function sign_manifest(manifest: UpdateManifest, private_key_pem: string): UpdateManifest;
export declare function verify_manifest(manifest: UpdateManifest, public_key: string): boolean;
export interface ManifestOptions {
    /** One per platform, as `build({ archive: true })` writes them. */
    fragments: UpdateFragment[];
    /** Where the archives are uploaded; each asset's URL is this plus the fragment's file name. */
    base_url: string;
    notes?: string;
    published_at?: string;
    url?: string;
    /** PEM; given, the manifest is signed. */
    private_key?: string;
}
/** One manifest from every platform's fragment; they have to agree on the version. */
export declare function build_manifest({ fragments, base_url, notes, published_at, url, private_key }: ManifestOptions): UpdateManifest;
