/**
 * `gpuix-svelte/build` — `Bun.build({ compile })` over a static-`render()` entry, then the
 * platform's packaging: a `.app` on macOS, a console-less `.exe` with version info on Windows,
 * a bare executable on Linux. Bun is the bundler, so this is Bun-only like plugin.ts.
 */
import { type AppInfo } from './app-bundle.js';
export type { AppInfo, UpdateFragment } from './app-bundle.js';
export interface BuildOptions {
    /** The entry that mounts the app with `render()` — `standalone.ts` in a scaffolded app. */
    entry: string | URL;
    /** Where the output goes; `dist` in the working directory by default. */
    outdir?: string | URL;
    /**
     * Also write the archive to distribute, `<slug>-<version>-<platform>.zip`,
     * and `update-<platform>.json` beside it, the fragment `gpuix-svelte update manifest` merges.
     */
    archive?: boolean;
    /** With `archive`, runs on the packaged output before macOS signing, so the signature and the archive both cover what it does: where a Windows `.exe` gets `signtool`, say. */
    beforeArchive?: (result: Pick<BuildResult, 'output' | 'binary' | 'app'>) => void | Promise<void>;
}
export interface BuildResult {
    /** What to ship: the `.app` on macOS, the `.exe` on Windows, the executable on Linux. */
    output: string;
    /** The executable itself, inside the `.app` on macOS. */
    binary: string;
    app: AppInfo;
    signed: boolean;
    notarized: boolean;
    /** With `archive: true`: the archive and its update fragment. */
    archive?: string;
    fragment?: string;
}
export declare function build(options: BuildOptions): Promise<BuildResult>;
